# ChatGPT Equation to Word

Ekstensi Chrome untuk menyalin equation ChatGPT sebagai UnicodeMath yang bisa ditempel ke Microsoft Word.

## Instalasi

1. Buka `chrome://extensions`.
2. Aktifkan **Developer mode**.
3. Klik **Load unpacked**.
4. Pilih folder `GPTEquation` ini.
5. Buka atau refresh halaman ChatGPT.

Klik ikon extension di toolbar untuk membuka popup status dan instruksi.
Pilih warna pada bagian **Warna highlight**, lalu klik **Simpan**. Warna baru berlaku langsung pada halaman ChatGPT yang terbuka.
Klik **Refresh equation** di popup untuk memindai ulang equation secara manual tanpa me-refresh halaman.
Klik equation yang diberi highlight untuk menyalinnya.

Jika berpindah ke chat baru atau kembali dari tab lain, tidak perlu refresh; extension akan memindai ulang halaman secara otomatis.
